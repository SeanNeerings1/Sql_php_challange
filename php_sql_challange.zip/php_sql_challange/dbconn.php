<?php

require 'vendor/autoload.php';

use Carbon\Carbon;


$mysqli = new mysqli("localhost", "root", "a", "php_mysql_challange");

if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}
// var_dump($_GET);
$videoId = 1;
$sql = "SELECT * FROM videos WHERE video_id = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $videoId);
$stmt->execute();
$result = $stmt->get_result();
$video = $result->fetch_assoc();

$sql = "SELECT * FROM posts WHERE video_id = ? ORDER BY date DESC";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $videoId);
$stmt->execute();
$comments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $userName = $_POST["user_name"];
    $dateTime = $_post["date"];
    $userEmail = $_POST["user_email"];
    $commentText = $_POST["comment_text"];

    // Validate user inputs
    if (empty($userName)) {
        die("Gebruikersnaam is verplicht.");
    }

    if (!filter_var($userEmail, FILTER_VALIDATE_EMAIL)) {
        die("Ongeldige e-mail.");
    }

    if (empty($commentText)) {
        die("Opmerkingen zijn verplicht.");
    }

    $commentText = htmlspecialchars($commentText, ENT_QUOTES, 'UTF-8');


    $sql = "INSERT INTO posts (video_id, user_name, user_email, comment_text) VALUES (?, ?, ?, ?)";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("isss", $videoId, $userName, $userEmail, $commentText);
    $stmt->execute();

    header("Location: video_page.php?video_id=" . $videoId);
    exit();
}

$mysqli->close();
?>

