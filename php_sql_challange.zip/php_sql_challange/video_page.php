<?php include "dbconn.php";?>

<?php
date_default_timezone_set("Europe/Amsterdam");

echo date("y/m/d h:i:sa");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Video Page</title>
</head>
<body>
    <h1><?php echo $video["title"]; ?></h1>

    <iframe width="560" height="315" src="<?php echo $video['video_url']?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    
    <h2>Add a Comment</h2>
    <form method="post" action="video_page.php?video_id=<?php echo $videoId; ?>">
        <label for="user_name">Your Name:</label>
        <input type="text" id="user_name" name="user_name" required><br>

        <label for="user_email">Your Email:</label>
        <input type="email" id="user_email" name="user_email" required><br>
        
        <label for="comment_text">Your Comment:</label>
        <textarea id="comment_text" name="comment_text" required></textarea><br>
        
        <input type="submit" value="Submit">
    </form>
    
    <h2>Comments</h2>
    <ul>
        <?php foreach ($comments as $comment): ?>
            <li>
                <strong><?php echo $comment["user_name"]; ?></strong> <?php echo ($comment["date"]) ?> <?php echo \Carbon\Carbon::createFromDate($comment["date"])->diffForHumans(); ?> <br> (Email: <?php echo $comment["user_email"]; ?>)<br>
                <?php echo $comment["comment_text"]; ?><br>
                
            </li>
        <?php endforeach; ?>
    </ul>


   
</body>
</html>
